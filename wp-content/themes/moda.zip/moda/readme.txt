Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/moda/
Buy theme: http://smthemes.com/buy/moda/
Support Forums: http://smthemes.com/support/forum/moda-free-wordpress-theme/