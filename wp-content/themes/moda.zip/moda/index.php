<?php 
	global $SMTheme;
	
	get_header(); 
	
	get_template_part('theloop');
	
	get_footer();
	
?>