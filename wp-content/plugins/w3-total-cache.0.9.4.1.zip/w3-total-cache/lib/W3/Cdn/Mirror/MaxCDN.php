<?php

/**
 * W3 CDN MaxCDN Class
 */
if (!defined('ABSPATH')) {
    die();
}

w3_require_once(W3TC_LIB_W3_DIR . '/Cdn/Mirror/Netdna.php');

/**
 * Class W3_Cdn_Mirror_MaxCDN
 */
class W3_Cdn_Mirror_MaxCDN extends W3_Cdn_Mirror_Netdna {}
