<?php if (!defined('W3TC')) die(); ?>
<p class="widget-loading hide-if-no-js {nonce: '<?php echo wp_create_nonce('w3tc'); ?>'}">
	<?php echo __( 'Loading&#8230;' ) ?>
</p>
<p class="hide-if-js">
	<?php echo __( 'This widget requires JavaScript.' ) ?>
</p>
